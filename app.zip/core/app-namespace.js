(function (global) {
  const App = global.App = global.App || {};
  App.state   = App.state   || {};
  App.ui      = App.ui      || {};
  App.config  = App.config  || {};
  App.core    = App.core    || {};
  App.svc     = App.svc     || {};
})(window);